/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file init.c
	@brief Simple logic function with LEDs and Buttons
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

#include <avr/io.h>
#include "init.h"

int main(void){


	// Init START
	init();
	// Init END

	while(1){
			
		//For RED
		if ((~PIND & (1 << PD2)) && (~PIND & (1 << PD3)))
			PORTB &= ~(1 << PB1);
		else
			PORTB |= (1 << PB1);	
			
		//For YELLOW	
		if ((~PIND & (1 << PD2)) && (~PIND & (1 << PD3)))
			PORTB |= (1 << PB2);
		
		else
			PORTB &= ~(1 << PB2);
		
		//For GREEN 
		if (!((~PIND & (1 << PD2))) != (!(~PIND & (1 << PD3))))
			PORTB |= (1 << PB3);
		
		else
			PORTB &= ~(1 << PB3);	

	}
	
	return 0;
}
