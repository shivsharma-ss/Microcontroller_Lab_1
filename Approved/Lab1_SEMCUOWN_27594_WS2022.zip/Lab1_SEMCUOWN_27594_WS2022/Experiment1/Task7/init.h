/**
	@author Thomas Grunenberg
	@author TODO
	@version 0.1
	@file init.c
	@brief Lab1 init, header file
*/

#ifndef INIT
#define INIT

void init(void);


#endif
