/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file init.c
	@brief Simple logic function with LEDs and Buttons
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

#include <avr/io.h>
#include "init.h"

int main(void){


	init();

	while(1){
	 
	 if ((~PINB & (1 << PB4))) 
			PORTB |= (1 << PB2);
		
		else
			PORTB &= ~(1 << PB2);

	}
	
	return 0;
}
