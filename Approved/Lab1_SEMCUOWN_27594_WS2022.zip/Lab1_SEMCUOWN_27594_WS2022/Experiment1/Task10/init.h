/**
	@author Thomas Grunenberg
	@author TODO
	@version 0.1
	@file init.h
	@brief Lab1 init, header file
*/

#ifndef INIT_H
#define INIT_H

void init(void);


#endif
