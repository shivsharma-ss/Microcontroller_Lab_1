/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file init.c
	@brief Simple logic function with LEDs and Buttons
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "init.h"

int main(void){


	init();

	while(1){
		

		if ((~PINB & (1 << PB4)) ){ // 
			PORTB ^= (1 << PB2);	// (R)
		
		
		while( ~PINB & 1<<PB4) 
		
		{
			_delay_ms(50); 
		}
		
		}


	}
	
	return 0;
}
