/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file main.c
	@brief Analog output via PWM
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "init.h"

int main(void){


	init();

	while(1){

		if ((~PIND & (1 << PD2)) ){
			PORTB ^= (1 << PB1);
		} else {
			//TODO: LED on
			PORTB ^= (1 << PB1);
			
		}
	}
	
	return 0;
}
