/**
	@author Thomas Grunenberg
	@author TODO
	@version 0.1
	@file init.h
	@brief Init function for the I/O
*/

#ifndef INIT
#define INIT

void init(void);


#endif
