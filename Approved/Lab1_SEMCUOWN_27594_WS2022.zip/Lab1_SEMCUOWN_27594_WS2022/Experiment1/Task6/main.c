#include <avr/io.h>
#include "init.h"

const char MtrNum[] __attribute__((__progmem__)) = "27594";

int main(void){


	// Init START
	init();
	// Init END

	while(1){
		if ((~PIND & (1 << PD2)) && (~PIND & (1 << PD3)))
			PORTB |= (1 << PB1);
		else
			PORTB &= ~(1 << PB1);	

	}
	
	return 0;
}
