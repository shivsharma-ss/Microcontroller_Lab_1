#ifndef INIT
#define INIT

void init(void);


#endif
