/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file main.c
	@brief ADC with three LEDs
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

/******************************************************************************/
/* INCLUDED FILES                                                             */
/******************************************************************************/
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "lcd.h"
#include "stdio.h"
#define F_CPU 8000000UL

/******************************************************************************/

/******************************************************************************/
/* FUNCTIONS                                                                  */
/******************************************************************************/

/**
	@brief Init the microcontroller
*/
void init(void){
	// Digital I/O init----------------------------------------------------
	DDRB &= ~(1 << DDB0);		// PB0 as Input (key 1)
	PORTB |= ( 1 << PB0);		// Pullup PB0


	// ADC init------------------------------------------------------------
	DDRC &= ~(1 << DDC3);		// PC3 as Input (Poti)
	PORTC &= ~(1 << DDC3);		// Pullup PC3 OFF
	DDRC &= ~(1 << DDC2);		// PC4 as Input (Poti)
	PORTC &= ~(1 << DDC2);		// Pullup PC4 OFF	
	
	// ADMUX
	ADMUX = 0;
	ADMUX |= (1 << REFS0); // AVCC as reference
	ADMUX |= (1 << MUX0)|(1 << MUX1);// Select Channel ADC3
	ADMUX |= (1 << MUX0)|(0 << MUX1);// Select Channel ADC2

	// ADCSRA
	ADCSRA = (1 << ADPS2)|(1 << ADPS1); // Set ADC Prescale to 64

	// Start conversion, Free running, Enalbe ADC
	ADCSRA |= (1 << ADSC)|(1 << ADATE)|(1 << ADEN); 

}
/******************************************************************************/




/**
	@brief Main function
	@return only a dummy to avoid a compiler warning, not used
*/
int main(void){
	
	// Init
	init();
	lcd_init();

	// Loop forever
	while (1){
		
		// Clearing screen
		lcd_clear();

		char buffer[13] = "\0";
		float voltage = 0;

		// pin C2
		// Clearing MUX0
		ADMUX &= ~(1 << MUX0) & ~(1 << MUX1) & ~(1 << MUX2) & ~(1 << MUX3);

		// Setting 0010 (Pin2)
		ADMUX |= (1 << MUX1);

		_delay_ms(10);

		voltage = ADCW;

		//To show values on lcd
		itoa(voltage, buffer, 10);
		lcd_setcursor(0, 1);
		lcd_string(buffer);


		// pin C3
		// Clearing MUX0
		ADMUX &= ~(1 << MUX0) & ~(1 << MUX1) & ~(1 << MUX2) & ~(1 << MUX3);

		// Setting 0010 (Pin 3)
		ADMUX |= (1 << MUX0) | (1 << MUX1);

		_delay_ms(10);

		voltage = ADCW;

		//To show values on lcd
		itoa(voltage, buffer, 10);
		lcd_setcursor(0, 2);
		lcd_string(buffer);

		_delay_ms(100);
	}
	
	return 0;
}
/******************************************************************************/
