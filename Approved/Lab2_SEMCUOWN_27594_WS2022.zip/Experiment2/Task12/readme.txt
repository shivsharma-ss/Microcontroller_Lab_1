myAVR board connections:
	PB0, PB1 -> Push buttons
	LCD module
	
Description:

	This program counts the number of button presses without debouncing. 
	If the button connected at PB0 will be pressed multiple times, e.g. 15-20 times, it is very likely to see a larger number on the LCD. 
	The difference in the number is due to bouncing effects of the push button.
	Try to use two wires instead of the pushbutton (connect one to the LOW connector on the myAVR board, another is PB0).
	How many bounces are counted if these two wires are connected?
	
	The button connected to PB1 reset the counter of bounces back to 0.