#define F_CPU 8000000UL						// Include CPU frequency
#include <avr/io.h>							// Include AVR I/O library
#include <avr/interrupt.h>					// Include interrupt library
#include <stdio.h>							// Include C standard I/O library
#include "lcd.h"							// Include LCD library
volatile uint8_t press_count = 0;			// Global variable to count bounces
int main(void){								// Main function
	lcd_init();								// LCD initialization
	PORTB = (1<<PB0)|(1<<PB1);				// Pullup resistors for PB0 and PB1
	TCCR0B = (1<<CS01);						// Timer 0 prescaler 8
	TIMSK0 = (1<<TOIE0);					// Enable Timer0 OVF Interrupt	
	TCCR1B = (1<<CS11);						// Timer 1 prescaler 8
	TIMSK1 = (1<<TOIE1);					// Enable Timer1 OVF Interrupt
	sei();									// Set global interrupt flag
	while (1){								// Main loop
		if (~PINB & (1<<PB0)) {				// If button at PB0 pressed...
			press_count++;					// ...increment counter...
			while (~PINB & (1<<PB0));		// ...and wait for button release
		}									// No debouncing delays!
	}	
	return 0;								// main() return value
}
ISR(TIMER0_OVF_vect) {						// Timer 0 OVF interrupt routine
	if (~PINB & (1<<PB1))					// If button at PB1 pressed...
		press_count = 0;					// ...reset counter
}
ISR(TIMER1_OVF_vect) {						// Timer 1 OVF interrupt routine
	char lcd_line[17];						// String variable
	lcd_clear();							// Clear LCD
	lcd_setcursor(0,1);						// Set cursor to line 1
	lcd_string("Presses detected");			// Print message
	sprintf(lcd_line, "%d", press_count);	// Format string with variable
	lcd_setcursor(0,2);						// Set cursor to line 2
	lcd_string(lcd_line);					// Print variable
}