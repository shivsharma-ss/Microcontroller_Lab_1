/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file main.c
	@brief Creating the frequency of 3xx Hz (student ID 12345 -> 345 Hz)
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

/******************************************************************************/
/* INCLUDED FILES                                                             */
/******************************************************************************/
#include <avr/io.h>
/******************************************************************************/


/******************************************************************************/
/* FUNCTIONS                                                                  */
#define F_CPU 8000000UL
#include <util/delay.h>  
/******************************************************************************/

/**
	@brief Init the microcontroller
*/
void init(void){

	DDRB |= (1 << DDB0); 
	TCCR1B |= (1<<CS10) | (1<<CS11);


}
/******************************************************************************/




/**
	@brief Main function
	@return only a dummy to avoid a compiler warning, not used
*/
int main(void){
	
	// Init
	init();
	TCNT1=0;

	// Loop forever
	while (1){
		
		if (TCNT1>=10152)
		{
			PORTB ^= (1<<PB0);
			_delay_ms(50);
			TCNT1=0;
		}

	}
	
	return 0;
}
/******************************************************************************/
