/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file main.c
	@brief Lab2 task 6
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

/******************************************************************************/
/* INCLUDED FILES                                                             */
/******************************************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
/******************************************************************************/


/******************************************************************************/
/* FUNCTIONS                                                                  */
#define F_CPU 8000000UL
#include <util/delay.h>
/******************************************************************************/

/**
	@brief Init the microcontroller
*/
void init(void){

	// Init key inputs
	DDRD &=  ~(1 << DDD2);		// PD2 input
	DDRD &=  ~(1 << DDD3);		// PD3 input
	PORTD |= (1 << PD2); // enable Pullup PD2
	PORTD |= (1 << PD3); // enable Pullup PD3

	// Init LED outputs
		DDRB |= (1 << PB0);  // red led
		DDRB |= (1 << PB1);  // yellow led
	
	// Enable interrupts
		EICRA |= (1 << ISC00);
		EICRA |+ (1 << ISC10);
		EIMSK = (1 << INT0) | (1 << INT1);
}
/******************************************************************************/




/**
	@brief Main function
	@return only a dummy to avoid a compiler warning, not used
*/
int main(void){
	
	// Init
	init();
	
	// Global interrupt enable
	sei();

	// Loop forever
	while (1){
		
		PORTB |= (1 << PB1);
		_delay_ms(250);
		
		PORTB &=~ (1 << PB1);
		_delay_ms(250);

	}
	
	return 0;
}
/******************************************************************************/

/**
	@brief INT0 interrupt
*/
ISR(INT0_vect){
	{
		PORTB |= (1 << PB0);
	}
}
/******************************************************************************/

/**
	@brief INT1 interrupt
*/
ISR(INT1_vect){
	{
		PORTB &=~ (1 << PB0);
	}
}
/******************************************************************************/