
/**
	@author Shivansh Sharma
	@author 27594
	@version 0.1
	@file main.c
	@brief Lab2 Task 13
*/

const char MtrNum[] __attribute__((__progmem__)) = "27594";

/******************************************************************************/
/* INCLUDED FILES                                                             */
/******************************************************************************/
#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>

/******************************************************************************/

/******************************************************************************/
/* FUNCTIONS                                                                  */
/******************************************************************************/

/**
	@brief Init the microcontroller
*/
void init(void){
	// Digital I/O init----------------------------------------------------
	DDRB |=  (1 << DDB1);		// PB1 as Output (PWM output for a servomotor)

	// ADC init------------------------------------------------------------
	DDRC &= ~(1 << DDC3);		// PC3 as Input (Poti)
	PORTC &= ~(1 << DDC3);		// Pullup PC3 OFF	
	
	// ADMUX
	ADMUX = 0;
	ADMUX |= (1 << REFS0)|(1 << ADLAR);	// AVCC as reference, ADLAR bit set
	ADMUX |= (1 << MUX1)|(1 << MUX0); 	// Select Channel ADC3

	// ADCSRA
	ADCSRA = (1 << ADPS2)|(1 << ADPS1); // Set ADC Prescale to 64

	// Start conversion, Free running, Enalbe ADC, Enable ADLAR
	ADCSRA |= (1 << ADSC)|(1 << ADATE)|(1 << ADEN)|(1 << ADLAR);

	// Timer init----------------------------------------------------------
	// Timer 0
	TIMSK0 = (1<<OCIE0B)|(1<<OCIE0A)|(1<<TOIE0); // Enable timer interrupt
	TCCR0B = (1<<CS01)|(1<<CS00); // Set prescaler to 64
	OCR0B = 255;
}
/******************************************************************************/


/**
	@brief Main function
	@return only a dummy to avoid a compiler warning, not used
*/
int main(void){
	
	// Init
	init();

	sei();

	uint16_t poti = ADCW;	//ADCW
	
	// Loop forever
	while (1){

		OCR0A =  (((poti-0)*(2-1))/(255-0))* 125;

	}
	
	return 0;
}
/******************************************************************************/

/**
	@brief Timer1 compare interrupt
*/
ISR(TIMER0_COMPA_vect){
	// off PB1
	PORTB &= ~(1<<PB1);
	
}
/******************************************************************************/
ISR(TIMER0_COMPB_vect){
	// on PB1
	TCNT0 = 0;
	PORTB |= (1<<PORTB1);
}

/******************************************************************************/
